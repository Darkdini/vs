'use strict';
// Игровое состояние тестового сервера: игроки, замки, ресурсы (ленивый расчёт), очередь строительства.
// Хранилище — один JSON-файл (см. Store ниже: атомарная запись и резервные копии).

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const zlib = require('zlib');
const C = require('./catalog');

const SPEED = Number(process.env.SPEED || 1);
// мир: карта WORLD×WORLD клеток, рассчитан на ~5 000 игроков (заселённый круг ~220 клеток)
const WORLD = Number(process.env.WORLD_SIZE || 1000);
const SPAWN_GAP = 2;
// провинции (как в оригинале): мир нарезан на квадраты PROV×PROV клеток (25×25; было 20×20 — стало просторнее); новые игроки заселяют провинцию по PROV_CAP замков,
// потом — следующую, по спирали от центра карты (соседи рядом). Внутренний номер провинции — по строкам, с 1; игрок видит номер
// по порядку заселения (provNo): №1 заселяется первой, потом №2 и т. д.
const PROV = 25, PROV_CAP = 10, PROV_EDGE = 2, PROV_N = Math.ceil(WORLD / PROV);
// клетки у границы провинции (по PROV_EDGE с каждой стороны линии) пустые: замки и лагеря не налезают на границу
const onProvEdge = (x, y) => { const a = ((x % PROV) + PROV) % PROV, b = ((y % PROV) + PROV) % PROV; return a < PROV_EDGE || a >= PROV - PROV_EDGE || b < PROV_EDGE || b >= PROV - PROV_EDGE; };
// в каждой провинции — одни руины, три лагеря разбойников: лёгкий, средний, тяжёлый (раньше было 26 объектов — на карте было тесно),
// и три рунных камня — Силы, Стойкости, Пути (runes.js; новые объекты дописаны в конец — места прежних не сдвинулись).
// Побеждённый лагерь и захваченные руины исчезают и через NPC_BACK_SEC появляются на новом свободном месте той же провинции (Game.provNpc)
const PROV_NPC = [[24, 'Заброшенный замок'], [30, 'Лагерь разбойников (лёгкий)'], [31, 'Лагерь разбойников (средний)'], [32, 'Лагерь разбойников (тяжёлый)'], ...Object.entries(require('./runes').RUNES).map(([img, r]) => [Number(img), r.name])];
const CAMP_IMGS = [30, 31, 32];
const NPC_BACK_SEC = 3 * 3600; // с 22.10 — 3 часа (было час): лагеря и руины давали заметный доход сверх замка; игроку время не показывается
// где объекты стоят сначала: по номеру провинции (всегда одинаково), внутри провинции (не у границы) и подальше друг от друга
const PROV_LAY = new Map();
const provLayout = (n) => {
  let L = PROV_LAY.get(n); if (L) return L;
  let seed = (n * 2654435761) >>> 0 || 1; const rnd = () => ((seed = (seed * 1103515245 + 12345) >>> 0) / 4294967296);
  const inner = PROV - 2 * PROV_EDGE, picked = [];
  for (let k = 0; k < PROV_NPC.length; k++) { // каждый следующий — подальше от уже поставленных (от 6 клеток — уже достаточно, дальше случайно)
    let best = null, bs = -1;
    for (let t = 0; t < 40; t++) { const x = Math.floor(rnd() * inner), y = Math.floor(rnd() * inner);
      const sc = Math.min(6, ...picked.map((q) => Math.hypot(q[0] - x, q[1] - y))) + rnd(); if (sc > bs) { bs = sc; best = [x, y]; } }
    picked.push(best);
  }
  L = PROV_NPC.map(([img, name], k) => ({ img, name, dx: picked[k][0], dy: picked[k][1] }));
  if (PROV_LAY.size > 5000) PROV_LAY.clear(); PROV_LAY.set(n, L); return L;
};
const provinceOf = (x, y) => { const px = Math.floor(x / PROV), py = Math.floor(y / PROV); return { px, py, n: py * PROV_N + px + 1 }; };
let PROV_ORDER = null; // провинции от центра карты к краям
const provOrder = () => PROV_ORDER || (PROV_ORDER = Array.from({ length: PROV_N * PROV_N }, (_, i) => i).map((i) => ({ px: i % PROV_N, py: Math.floor(i / PROV_N) }))
  .map((p) => ({ ...p, d: Math.hypot((p.px + 0.5) * PROV - WORLD / 2, (p.py + 0.5) * PROV - WORLD / 2), a: Math.atan2((p.py + 0.5) * PROV - WORLD / 2, (p.px + 0.5) * PROV - WORLD / 2) }))
  .sort((p, q) => Math.round(p.d / PROV) - Math.round(q.d / PROV) || p.a - q.a));
// номер провинции, который видит игрок, — по порядку заселения: №1…№4 в центре карты, вокруг — №5…№16 и дальше кругами,
// так что новички заполняют №1, потом №2 и т. д. Внутри игры провинция — по строкам (provinceOf(…).n: раскладка лагерей и рун, db.pnpc);
// на карте, в поиске «Провинция №» и в сообщениях — provNo(n). Клиент получает таблицу в каталоге (web.js rules.provNo).
let PROV_NO = null;
const provNo = (n) => { if (!PROV_NO) { PROV_NO = new Array(PROV_N * PROV_N); provOrder().forEach((p, i) => { PROV_NO[p.py * PROV_N + p.px] = i + 1; }); } return PROV_NO[n - 1] || n; };
// где на нарисованном фоне карты мира луг, а не роща (world_open.json — маска картинки web/gfx/ground/world_bg.jpg):
// клетка мира (X, Y) лежит в точке фона ((X+Y)·31+31, (Y−X)·16+16) по модулю размера картинки.
// Сейчас фон — ровная трава без рощ, маски нет: луг везде
const WOPEN = (() => { try { const j = require('./world_open.json'); return { ...j, b: Buffer.from(j.bits, 'base64') }; } catch { return null; } })();
const meadowAt = (X, Y) => { if (!WOPEN) return true; const m = (a, n) => ((a % n) + n) % n;
  const px = m((X + Y) * 31 + 31, WOPEN.W), py = m((Y - X) * 16 + 16, WOPEN.H), i = Math.floor(py / WOPEN.S) * WOPEN.w + Math.floor(px / WOPEN.S);
  return !!(WOPEN.b[i >> 3] & (128 >> (i & 7))); };     // новый замок — не ближе 2 клеток к другим замкам (между замками хотя бы одна пустая клетка)
const SAVE_MS = Number(process.env.SAVE_MS || 10000); // автосохранение раз в 10 с (и при остановке)
const DEMOLISH_SEC = Math.max(5, Math.round(1800 / SPEED)); // снос здания — 30 минут (castle.razing)
const MAX_QUEUE = Number(process.env.MAX_QUEUE || 3); // оригинал: 3 стройки одновременно (премиум — 5)

// ---------- рельеф «Земель» ----------
// рельеф «Земель» 15×15 (как в оригинале): массивы j/k/l из клиента. base: 0 трава, 7 земля, 8 камни, 9 вода; decor: 0 лес, 1 валун, 2 гора
const LANDS_N = C.LANDS_N;
const LANDS_BASE = [
  [7, 7, 7, 7, 7, 7, 0, 0, 0, 8, 8, 8, 8, 8, 8], [7, 7, 7, 7, 7, 0, 0, 0, 0, 8, 8, 8, 8, 8, 8],
  [7, 7, 7, 7, 7, 0, 0, 0, 0, 8, 8, 8, 8, 8, 8], [7, 7, 7, 7, 7, 7, 0, 0, 0, 8, 8, 8, 8, 8, 8],
  [7, 7, 7, 7, 7, 7, 0, 0, 0, 8, 8, 8, 8, 8, 8], [7, 7, 7, 7, 7, 7, 0, 0, 0, 0, 0, 8, 8, 8, 8],
  [7, 7, 7, 7, 7, 0, 0, 0, 0, 0, 0, 8, 8, 8, 8], [0, 0, 7, 7, 7, 0, 0, 0, 0, 0, 0, 0, 0, 8, 8],
  [0, 0, 7, 7, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], [0, 0, 7, 7, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
  [0, 0, 7, 7, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], [0, 0, 0, 0, 0, 0, 0, 9, 9, 9, 9, 0, 0, 0, 0],
  [0, 0, 0, 0, 0, 0, 9, 9, 9, 9, 9, 9, 0, 0, 0], [0, 0, 9, 9, 9, 9, 9, 9, 0, 0, 9, 9, 9, 9, 9],
  [0, 0, 9, 9, 9, 9, 9, 9, 0, 0, 9, 9, 9, 9, 9],
];
const LANDS_DECOR = [
  [-1, -1, -1, -1, -1, -1, -1, -1, -1, 1, 1, 2, 2, 2, 2], [-1, 1, 1, 1, -1, -1, -1, -1, -1, 2, 1, 1, 2, 2, 2],
  [-1, -1, 1, 1, -1, -1, -1, -1, -1, 2, 2, 1, 2, 2, 2], [-1, -1, -1, -1, 1, -1, -1, -1, -1, 1, 2, 1, 1, 2, 2],
  [-1, -1, -1, -1, -1, -1, -1, -1, -1, 2, 2, 2, 2, 1, 2], [-1, -1, -1, -1, -1, -1, -1, -1, -1, 1, 1, 1, 2, 1, 2],
  [-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 1, 1, 1, 2, 1], [0, 0, -1, -1, -1, -1, -1, -1, -1, -1, 1, 1, 1, 2, 2],
  [0, 0, -1, -1, -1, -1, -1, -1, -1, -1, 0, 0, 0, 0, 0], [0, 0, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 0, 0, 0],
  [0, 0, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 0, 0], [0, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 0, 0],
  [0, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 0], [0, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1],
  [0, 0, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1],
];
const LANDS_EDGE = [
  [-1, -1, -1, -1, -1, 4, -1, -1, -1, 2, -1, -1, -1, -1, -1], [-1, -1, -1, -1, 0, -1, -1, -1, -1, 2, -1, -1, -1, -1, -1],
  [-1, -1, -1, -1, 0, -1, -1, -1, -1, 2, -1, -1, -1, -1, -1], [-1, -1, -1, -1, -1, 10, -1, -1, -1, 2, -1, -1, -1, -1, -1],
  [-1, -1, -1, -1, -1, 0, -1, -1, -1, 6, 1, -1, -1, -1, -1], [-1, -1, -1, -1, -1, 4, -1, -1, -1, -1, -1, 2, -1, -1, -1],
  [1, 1, -1, -1, 0, -1, -1, -1, -1, -1, -1, 6, 1, -1, -1], [-1, -1, 2, -1, 4, -1, -1, -1, -1, -1, -1, -1, -1, 6, 1],
  [-1, -1, 2, 0, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1], [-1, -1, 2, 0, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1],
  [-1, -1, 6, 4, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1], [-1, -1, -1, -1, -1, -1, -1, 20, 15, 15, 22, -1, -1, -1, -1],
  [-1, -1, -1, -1, -1, -1, 20, 17, 13, 13, 19, 22, -1, -1, -1], [-1, -1, 20, 15, 15, 15, 21, 12, -1, -1, 14, 23, 15, 15, 15],
  [-1, -1, 14, -1, -1, -1, -1, 12, -1, -1, 14, -1, -1, -1, -1],
];

// Какие здания можно ставить на клетку земель
function landOptions(x, y) {
  // края дорог и берегов (LANDS_EDGE) — только рисунок, застраивать можно все 225 клеток
  if (LANDS_BASE[y][x] === 9 || LANDS_EDGE[y][x] >= 12) return [37]; // вода и берег — Рыболовная заводь
  switch (LANDS_DECOR[y][x]) {
    case 0: return [7];
    case 1: return [8];
    case 2: return [9];
    default: return LANDS_BASE[y][x] === 7 ? [5] : [6]; // как в оригинале: Огород — на вспаханной земле, Хибара — на траве
  }
}

// вместимость: 200 базово + вместимость каждого Склада по уровню (1–20 ур.), Склады суммируются;
// 1–8 ур. — как в оригинале (старт: Склад 2 ур. вмещает 500), с 9-го — +1 330 за уровень
// → 5 Складов 20 ур. = 200 + 5 × 18 960 = 95 000; места для людей: 35 + 4.728 за уровень Хибары → полный замок 5 425
const STORE = { base: 200, levels: [0, 100, 300, 500, 800, 1000, 1500, 2000, 3000, 4330, 5660, 6990, 8320, 9650, 10980, 12310, 13640, 14970, 16300, 17630, 18960], people: 35, peoplePerHut: 4.728 };
const storeBonus = (level) => STORE.levels[Math.max(0, Math.min(20, level))];
// добыча ресурсов не ускоряется скоростью мира (числа как в оригинале); RES_SPEED — отдельный множитель для тестов
const RES_SPEED = Number(process.env.RES_SPEED || 1);
const PEOPLE_SCI = (1400 / 1303 - 1) / 20; // прирост людей за уровень Экономики: на 20 ур. — 1400 в час при полных землях, как в оригинале
// базовая добыча замка в час (без зданий); Хибара даёт людей с коэффициентом 0.2 от таблицы PROD
const BASE_RATE = { wood: 29.5, stone: 29.5, iron: 29.5, food: 29.5, people: 14 };
const PEOPLE_FACTOR = C.PROD_K.people;

const VIEW = { CASTLE: 0, LANDS: 1, WORLD: 2 };
const GRID = { [VIEW.CASTLE]: 7, [VIEW.LANDS]: LANDS_N };

// ---------- хранилище ----------
// сетки замков (здания и уровни) — байтовые массивы Int8Array: в памяти в ~8 раз меньше обычных массивов,
// в файле — строка «~base64»
const pack = (a) => `~${Buffer.from(a.buffer, a.byteOffset, a.byteLength).toString('base64')}`;
function PACK_THIS() { return pack(this); }
const unpack = (s) => { const b = Buffer.from(s.slice(1), 'base64'); return new Int8Array(b.buffer, b.byteOffset, b.length).slice(); };
const packCastle = (c) => { for (const v of [0, 1]) { if (!ArrayBuffer.isView(c.grid[v])) c.grid[v] = Int8Array.from(c.grid[v]); if (!ArrayBuffer.isView(c.levels[v])) c.levels[v] = Int8Array.from(c.levels[v]); } return c; };

// Хранилище: один JSON-файл. Защита данных игроков:
// • запись атомарная: сначала .tmp + fsync, потом переименование — при сбое питания остаётся старая целая копия;
// • резервные копии (gzip) в папке backups рядом с базой: при каждом запуске и раз в BACKUP_MS (час), хранятся последние 48 + 10 стартовых;
// • битая база не перезаписывается: сервер останавливается с подсказкой, как восстановить из копии.
const BACKUP_MS = Number(process.env.BACKUP_MS || 3600000);
class Store {
  constructor(file) {
    this.file = file;
    this.data = { nextId: 1, users: {}, castles: {} };
    if (fs.existsSync(file)) {
      try { this.data = JSON.parse(fs.readFileSync(file, 'utf8'), (k, v) => (typeof v === 'string' && v[0] === '~' ? unpack(v) : v)); } catch (e) {
        console.error(`База ${file} повреждена (${e.message}). Сервер остановлен, база не тронута. Восстановление из копии: sh /opt/war/game/restore.sh`);
        process.exit(2);
      }
      this.backup('start');
    }
    this.data.version = this.data.version || 1; // версия схемы — для будущих миграций при обновлениях
    this.timer = null;
    if (BACKUP_MS > 0 && !process.env.NO_BACKUP) this.bTimer = setInterval(() => { try { this.flush(); this.backup('auto'); } catch (e) { console.error('бэкап:', e.message); } }, BACKUP_MS).unref();
  }
  get backupDir() { return path.join(path.dirname(path.resolve(this.file)), 'backups'); }
  // копия текущего файла базы: backups/db-2026-09-28_1530-auto.json.gz
  backup(kind) {
    if (process.env.NO_BACKUP || !fs.existsSync(this.file)) return null;
    fs.mkdirSync(this.backupDir, { recursive: true });
    const d = new Date(), p2 = (n) => String(n).padStart(2, '0');
    const name = `db-${d.getFullYear()}-${p2(d.getMonth() + 1)}-${p2(d.getDate())}_${p2(d.getHours())}${p2(d.getMinutes())}${p2(d.getSeconds())}-${kind}.json.gz`;
    const out = path.join(this.backupDir, name);
    fs.writeFileSync(out, zlib.gzipSync(fs.readFileSync(this.file)));
    const keep = { start: 10, auto: 48, manual: 20 }[kind] || 20;
    const same = fs.readdirSync(this.backupDir).filter((f) => f.endsWith(`-${kind}.json.gz`)).sort();
    for (const f of same.slice(0, Math.max(0, same.length - keep))) fs.unlinkSync(path.join(this.backupDir, f));
    return out;
  }
  // запись не чаще раза в SAVE_MS, компактный JSON
  save() {
    if (this.timer) return;
    this.timer = setTimeout(() => { this.timer = null; this.flush(); }, SAVE_MS);
  }
  flush() {
    clearTimeout(this.timer); this.timer = null;
    fs.mkdirSync(path.dirname(this.file), { recursive: true });
    const tmp = this.file + '.tmp', fd = fs.openSync(tmp, 'w');
    // клетки замков (Int8Array) — строкой base64; через toJSON, а не функцию-фильтр: та вызывалась на каждое значение базы, запись была вдвое дольше
    Int8Array.prototype.toJSON = PACK_THIS;
    try { fs.writeSync(fd, JSON.stringify(this.data)); fs.fsyncSync(fd); } finally { delete Int8Array.prototype.toJSON; fs.closeSync(fd); }
    fs.renameSync(tmp, this.file);
  }
}

const hashPassword = (pass, salt = crypto.randomBytes(8).toString('hex')) =>
  `${salt}:${crypto.scryptSync(pass, salt, 32).toString('hex')}`;
// журнал паролей: каждая версия — {at, by, ip, dev, h}. h — тот же стойкий хеш (scrypt с солью), что и в u.pass:
// сам пароль нигде не хранится и не показывается; админ может только проверить, совпадает ли названный игроком пароль с одним из прежних
const PASS_LOG_MAX = 30;
function passLogPush(user, by, ip = '', dev = '') {
  if (!user.passLog) user.passLog = [{ at: user.created || Date.now(), by: 'reg', ip: user.regIp || '', h: user.pass }];
  user.passLog.push({ at: Date.now(), by, ip: String(ip || ''), dev: String(dev || '').slice(0, 12), h: user.pass });
  if (user.passLog.length > PASS_LOG_MAX) user.passLog.splice(0, user.passLog.length - PASS_LOG_MAX);
}
const checkPassword = (pass, stored) => { const a = Buffer.from(hashPassword(pass, stored.split(':')[0])), b = Buffer.from(stored); return a.length === b.length && crypto.timingSafeEqual(a, b); };

// реальное время стройки с учётом скорости мира (не меньше 3 с)
const buildTime = (def, level, townhall) => Math.max(3, Math.round(C.levelTimeSec(def, level, townhall) / SPEED));

// перенос старых земель (15×15 или 7×7) на новые: постройки каждого вида встают на клетки своего вида, а их суммарная добыча
// (уровни прежних зданий) переводится в уровни новых — до 25 ур. Стройки на землях отменяются с возвратом ресурсов.
function migrateLands(castle) {
  const N = LANDS_N, g0 = castle.grid[1], l0 = castle.levels[1];
  const sum = {};
  const om = C.LAND_MULT_BY_SIZE[g0.length] || {}; // множитель добычи прежней раскладки
  for (let i = 0; i < g0.length; i++) if (g0[i] >= 0 && C.LAND_MULT[g0[i]]) sum[g0[i]] = (sum[g0[i]] || 0) + C.PROD[l0[i]] * (om[g0[i]] || 1);
  const g = new Int8Array(N * N).fill(-1), l = new Int8Array(N * N);
  for (const [b, total] of Object.entries(sum)) {
    const cells = []; for (let y = 0; y < N; y++) for (let x = 0; x < N; x++) if (landOptions(x, y)[0] === Number(b)) cells.push(y * N + x);
    let left = total / C.LAND_MULT[b]; // столько «добычи на новом уровне» надо набрать
    for (const c of cells) {
      if (left < C.PROD[1] * 0.5 && c !== cells[0]) break; // хотя бы одна постройка вида остаётся
      let lv = 1; while (lv < C.LAND_EFF_MAX && C.PROD[lv + 1] <= left + 1e-9) lv++; // прежние уровни 1–20 (потом — в новые, landsV)
      g[c] = Number(b); l[c] = lv; left -= C.PROD[lv];
    }
  }
  const back = (castle.queue || []).filter((q) => q.view === 1);
  for (const q of back) for (const r of ['wood', 'stone', 'iron', 'food']) castle.res[r] += (q.cost && q.cost[r]) || 0;
  castle.queue = (castle.queue || []).filter((q) => q.view !== 1);
  castle.grid[1] = g; castle.levels[1] = l; castle.landsV = 1;
}

// земли: уровни 1–20 → 1–5 (C.landFromOld: ближайший из 1, 5, 10, 15, 20). Стройки на землях — к следующему новому уровню
// (если новый уровень уже не выше — стройка отменяется с возвратом ресурсов)
function landsToV2(castle) {
  if (castle.landsV === 2) return;
  const l = castle.levels[1];
  for (let i = 0; i < l.length; i++) if (l[i] > 0) l[i] = C.landFromOld(l[i]);
  const keep = [];
  for (const q of castle.queue || []) {
    if (q.view !== 1) { keep.push(q); continue; }
    const cur = q.cell >= 0 ? l[q.cell] || 0 : 0, to = Math.max(cur + 1, C.landFromOld(q.level));
    if (to > C.LANDS_MAX || keep.some((k) => k.view === 1 && k.cell === q.cell)) { for (const r of ['wood', 'stone', 'iron', 'food']) castle.res[r] += (q.cost && q.cost[r]) || 0; continue; }
    q.level = to; keep.push(q);
  }
  castle.queue = keep; castle.landsV = 2;
}

// площадь в центре земель: если там стояла постройка (до появления площади) — переезжает на свободную клетку своего вида,
// а если свободной нет — её уровни добавляются к самой слабой постройке того же вида
// Стена (Забор, id 22) не занимает клетку: её уровень — castle.wall, развивается из Ратуши.
// Старые замки: Забор с клетки переносится в castle.wall (клетка освобождается), стройка Забора на клетке — в стройку стены.
const WALL_ID = 22;
function fixWall(castle) {
  if (castle.wall === undefined) castle.wall = 0;
  const g = castle.grid[0], l = castle.levels[0];
  for (let i = 0; i < g.length; i++) if (g[i] === WALL_ID) { castle.wall = Math.max(castle.wall, l[i]); g[i] = -1; l[i] = 0; }
  for (const q of castle.queue || []) if (q.building === WALL_ID && !q.wall) { q.wall = true; q.cell = -1; q.level = Math.max(q.level, castle.wall + 1); }
}
function fixPlaza(castle) {
  const N = LANDS_N, g = castle.grid[1], l = castle.levels[1];
  for (let y = 0; y < N; y++) for (let x = 0; x < N; x++) {
    const i = y * N + x; if (g[i] < 0 || landOptions(x, y).length) continue;
    const b = g[i], lv = l[i]; g[i] = -1; l[i] = 0;
    castle.queue = (castle.queue || []).filter((q) => !(q.view === 1 && q.cell === i));
    let free = -1, weak = -1;
    for (let k = 0; k < N * N; k++) { if (landOptions(k % N, Math.floor(k / N))[0] !== b) continue; if (g[k] < 0 && free < 0) free = k; if (g[k] === b && (weak < 0 || l[k] < l[weak])) weak = k; }
    if (free >= 0) { g[free] = b; l[free] = lv; } else if (weak >= 0) l[weak] = Math.min(C.LANDS_MAX, l[weak] + lv);
  }
}

class Game {
  constructor(store) {
    this.store = store; this.db = store.data;
    this.byXY = new Map(); // индекс замков по координатам: карта мира и поиск цели без перебора всех
    this.byId = new Map(); // игроки по id
    for (const c of Object.values(this.db.castles)) { packCastle(c); if (c.grid[1].length !== LANDS_N * LANDS_N) migrateLands(c); landsToV2(c); fixPlaza(c); fixWall(c); this.byXY.set(c.x * WORLD + c.y, c); }
    for (const u of Object.values(this.db.users)) this.byId.set(u.id, u);
    // ключ игрока = ник с учётом регистра; старые записи (ключ строчными, ник «Zevs») переносятся на ключ «Zevs»
    for (const [k, u] of Object.entries(this.db.users)) if (k !== u.login) { if (Object.prototype.hasOwnProperty.call(this.db.users, u.login)) u.login = k; else { delete this.db.users[k]; this.db.users[u.login] = u; } }
    // логин для входа (Email / Логин) — отдельно от ника; у старых игроков логином становится прежний ник (строчными)
    this.db.accts = Object.create(null);
    for (const [k, u] of Object.entries(this.db.users)) {
      if (!u.acct) { u.acct = String(u.login).toLowerCase(); if (this.db.accts[u.acct]) u.acct += `_${u.id}`; }
      this.db.accts[u.acct] = k;
    }
    this.cache = {};
    for (const c of Object.values(this.db.castles)) { this.castleLayoutFix(c); this.goneFix(c); }
    if (this.heroGearMerge) this.heroGearMerge(); // Оружейная — одна на королевство (hero.js)
    if (this.generalOneFix) this.generalOneFix(); // генерал — один на королевство (army.js)
    this.provEdgeFix();
    this.npcCleanup();
    if (this.allyCleanup) this.allyCleanup(); // пустые альянсы (участники удалены) — убрать отовсюду
    if (this.multiCleanup) this.multiCleanup(); // баны «железа» больше не действуют (security.js)
    if (this.stashCutOnce) this.stashCutOnce(); // разовый сброс излишков Кладовой (stash.js)
  }
  castleAt(x, y) { return this.byXY.get(x * WORLD + y); }
  // ----- руины и лагеря провинций -----
  // места объектов провинции n, как записаны: сначала — из provLayout, после переезда — db.pnpc[n][img] = { x, y };
  // побеждённый лагерь (захваченные руины) — { back, ox, oy }: не виден до back
  npcRaw(n) {
    const st = (this.db.pnpc || {})[n], px = (n - 1) % PROV_N, py = Math.floor((n - 1) / PROV_N);
    return provLayout(n).map((d) => { const s = st && st[d.img];
      return s && s.back ? { img: d.img, name: d.name, back: s.back, ox: s.ox, oy: s.oy } : { img: d.img, name: d.name, x: s ? s.x : px * PROV + PROV_EDGE + d.dx, y: s ? s.y : py * PROV + PROV_EDGE + d.dy }; });
  }
  // что сейчас стоит в провинции n: [{ img, name, x, y }]. Вернувшийся после победы объект встаёт на новое место;
  // замок на клетке объекта или вплотную к ней (поставлен до новых правил) — объект переезжает, замки не двигаются
  provNpc(n, now = Date.now()) {
    const out = [];
    for (const o of this.npcRaw(n)) {
      let p = o;
      if (o.back) { if (o.back > now) continue; p = this.npcMove(n, o.img, now, o.ox, o.oy); }
      else if (this.npcCrowded(o.x, o.y)) p = this.npcMove(n, o.img, now, o.x, o.y);
      if (p && p.x < WORLD && p.y < WORLD) out.push({ img: o.img, name: o.name, x: p.x, y: p.y });
    }
    return out;
  }
  npcCrowded(x, y) { for (let dx = -1; dx <= 1; dx++) for (let dy = -1; dy <= 1; dy++) if (this.castleAt(x + dx, y + dy)) return true; return false; }
  // новое место объекта img в провинции n: не у границы, не вплотную к замкам, другим объектам, логовам «Тёмных земель» и мировому боссу;
  // из случайных клеток — та, что подальше от замков, объектов и прежнего места (ox, oy). Места нет — новая попытка через 10 минут
  npcMove(n, img, now, ox, oy) {
    const S = (this.db.pnpc = this.db.pnpc || {}), st = S[n] || (S[n] = {});
    const px = (n - 1) % PROV_N, py = Math.floor((n - 1) / PROV_N), x0 = px * PROV + PROV_EDGE, y0 = py * PROV + PROV_EDGE;
    const w = Math.min(PROV - 2 * PROV_EDGE, WORLD - x0), h = Math.min(PROV - 2 * PROV_EDGE, WORLD - y0);
    const busy = this.npcRaw(n).filter((o) => o.img !== img && !o.back).map((o) => [o.x, o.y]); // другие объекты: вплотную нельзя
    for (const u of Object.values(this.db.users)) { const l = u.quests && u.quests.lair; if (l && l.x >= x0 - 1 && l.y >= y0 - 1 && l.x <= x0 + w && l.y <= y0 + h) busy.push([l.x, l.y]); }
    const boss = this.bossNow && this.bossNow(); if (boss) busy.push([boss.x, boss.y]);
    const far = [...busy];
    for (let y = y0 - 2; y < y0 + h + 2; y++) for (let x = x0 - 2; x < x0 + w + 2; x++) if (this.castleAt(x, y)) far.push([x, y]); // замки провинции
    if (ox !== undefined) far.push([ox, oy]);
    let best = null, bs = -1;
    for (let k = 0; k < 80 && w > 0 && h > 0; k++) {
      const x = x0 + Math.floor(Math.random() * w), y = y0 + Math.floor(Math.random() * h);
      if ((x === ox && y === oy) || !meadowAt(x, y) || this.npcCrowded(x, y) || busy.some((q) => Math.abs(q[0] - x) <= 1 && Math.abs(q[1] - y) <= 1)) continue;
      const sc = Math.min(6, ...far.map((q) => Math.hypot(q[0] - x, q[1] - y))) + Math.random();
      if (sc > bs) { bs = sc; best = { x, y }; }
    }
    if (ox !== undefined && this.db.npc) delete this.db.npc[`${ox}:${oy}`]; // руины на новом месте — новые (бунт и запас с нуля)
    st[img] = best || { back: now + 600000, ox, oy };
    this.store.save();
    return best;
  }
  // лагерь побеждён или руины захвачены: объект исчезает с карты и через NPC_BACK_SEC (с учётом скорости мира) появляется на новом месте провинции.
  // Возвращает, через сколько секунд он вернётся (null — объекта на (x, y) нет)
  npcGone(x, y, now = Date.now(), backSec = NPC_BACK_SEC) {
    const p = provinceOf(x, y), o = this.provNpc(p.n, now).find((q) => q.x === x && q.y === y); if (!o) return null;
    const S = (this.db.pnpc = this.db.pnpc || {}), st = S[p.n] || (S[p.n] = {}), sec = Math.round(backSec / SPEED);
    st[o.img] = { back: now + sec * 1000, ox: x, oy: y };
    if (this.db.npc) delete this.db.npc[`${x}:${y}`];
    this.store.save();
    return sec;
  }
  // руины и лагеря в прямоугольнике (без замков)
  npcIn(x0, y0, w, h) {
    const out = [], pa = Math.max(0, Math.floor(x0 / PROV)), pb = Math.min(PROV_N - 1, Math.floor((x0 + w - 1) / PROV));
    const qa = Math.max(0, Math.floor(y0 / PROV)), qb = Math.min(PROV_N - 1, Math.floor((y0 + h - 1) / PROV));
    for (let py = qa; py <= qb; py++) for (let px = pa; px <= pb; px++) for (const o of this.provNpc(py * PROV_N + px + 1)) {
      if (o.x >= x0 && o.y >= y0 && o.x < x0 + w && o.y < y0 + h && !this.castleAt(o.x, o.y)) out.push(o);
    }
    return out;
  }
  // записи о запасе и бунте (db.npc) — только у руин, что стоят сейчас; прежние записи (лагеря Дикарей, Лесорубов, старые места) — убрать
  npcCleanup() {
    const N = this.db.npc; if (!N) return;
    for (const k of Object.keys(N)) { const [x, y] = k.split(':').map(Number); if (!this.npcIn(x, y, 1, 1).some((o) => o.img === 24)) delete N[k]; }
  }
  // есть ли вплотную (8 соседних клеток) лагерь или руины — на карте мира их картинки налезали бы на замок
  objNear(x, y) { return this.npcIn(x - 1, y - 1, 3, 3).some((o) => o.x !== x || o.y !== y); }
  // замки, что стоят у самой границы провинции (поставлены до провинций или до их увеличения), — на ближайшую свободную клетку внутри той же провинции;
  // армии, идущие к старому месту, идут к новому. Руины и лагеря рядом с замками переезжают сами (provNpc)
  provEdgeFix() {
    let moved = 0;
    for (const c of [...this.byXY.values()]) {
      if (!onProvEdge(c.x, c.y)) continue;
      const px = Math.floor(c.x / PROV), py = Math.floor(c.y / PROV); let best = null;
      for (let gap = SPAWN_GAP; gap >= 0 && !best; gap--) for (let y = py * PROV + PROV_EDGE; y < (py + 1) * PROV - PROV_EDGE; y++) for (let x = px * PROV + PROV_EDGE; x < (px + 1) * PROV - PROV_EDGE; x++) {
        if (x >= WORLD || y >= WORLD || this.byXY.has(x * WORLD + y)) continue;
        let near = false; for (let dx = -gap; dx <= gap && !near; dx++) for (let dy = -gap; dy <= gap; dy++) { const k = this.castleAt(x + dx, y + dy); if (k && k !== c) { near = true; break; } }
        if (near || this.worldObjects(x, y, 1, 1).length || this.objNear(x, y)) continue;
        const d = Math.hypot(x - c.x, y - c.y); if (!best || d < best.d) best = { x, y, d };
      }
      if (!best) continue;
      const ox = c.x, oy = c.y; this.moveCastle(c, best.x, best.y); moved++;
      for (const k of Object.values(this.db.castles)) for (const a of k.armies || []) if (a.x === ox && a.y === oy) { a.x = best.x; a.y = best.y; }
    }
    if (moved) { this.cache = {}; this.store.save(); }
    return moved;
  }
  // можно ли поставить замок на (x, y): в пределах мира, не у границы провинции, не на лагере/объекте, вокруг (SPAWN_GAP) — ни одного замка,
  // в провинции меньше PROV_CAP замков. except — замок, который переносится (его самого не считаем). Возвращает текст ошибки или null.
  placeError(x, y, except = null) {
    if (!Number.isInteger(x) || !Number.isInteger(y) || x < 0 || y < 0 || x >= WORLD || y >= WORLD) return `Координаты — от 0 до ${WORLD - 1}.`;
    if (onProvEdge(x, y)) return 'Это граница провинции — замок там не поставить.';
    if (!meadowAt(x, y)) return 'Там лес — замок не поставить.';
    for (let dx = -SPAWN_GAP; dx <= SPAWN_GAP; dx++) for (let dy = -SPAWN_GAP; dy <= SPAWN_GAP; dy++) { const k = this.castleAt(x + dx, y + dy); if (k && k !== except) return dx || dy ? `Слишком близко к другому замку — между замками нужно ${SPAWN_GAP} пустые клетки.` : 'Клетка занята замком.'; }
    if (this.worldObjects(x, y, 1, 1).some((o) => o.kind === 'object')) return 'Клетка занята (лагерь или руины).';
    if (this.objNear(x, y)) return 'Рядом лагерь или руины — нужна хотя бы одна пустая клетка между ними.';
    const p = provinceOf(x, y); let n = 0; for (const k of this.byXY.values()) if (k !== except && provinceOf(k.x, k.y).n === p.n) n++;
    if (n >= PROV_CAP) return `Провинция №${provNo(p.n)} заполнена (${PROV_CAP} замков).`;
    return null;
  }
  moveCastle(c, x, y) { this.byXY.delete(c.x * WORLD + c.y); c.x = x; c.y = y; this.byXY.set(x * WORLD + y, c); }
  removeCastle(c) { this.byXY.delete(c.x * WORLD + c.y); delete this.db.castles[c.id]; }
  // кэш тяжёлых выборок по всем игрокам (рейтинги, Зал Славы) — пересчёт раз в ttl мс
  cached(key, ttl, fn) { const e = this.cache[key]; if (e && Date.now() - e.at < ttl) return e.v; const v = fn(); this.cache[key] = { at: Date.now(), v }; return v; }
  // таблица рейтинга игроков (кэш 15 с)
  leaderboard() { return this.cached('lb', 15000, () => Object.values(this.db.users).map((u) => ({ u, r: this.userRating(u) })).sort((a, b) => b.r - a.r)); }

  // ----- аккаунты -----
  // регистрация: логин (Email / Логин — для входа, без учёта регистра), пароль и ник (имя в игре, с учётом регистра: Zevs и zevs — разные)
  register({ login, password, email, race, nick, system }) {
    const acct = String(login || '').trim().toLowerCase();
    nick = String(nick == null || nick === '' ? String(login || '').trim() : nick).trim();
    login = nick;
    password = String(password || '').toLowerCase(); // клиент приводит пароль к нижнему регистру при входе
    if (!/^[a-zа-яё0-9_.@-]{1,40}$/i.test(acct)) return { error: 'Email / Логин: до 40 символов (буквы, цифры, _ . @ -).' };
    if (acct.length < 5 && !system) return { error: 'Логин слишком короткий (минимум 5 символов).' }; // старые короткие логины входят как раньше
    // ник: английские буквы, цифры и «_»; без мата, оскорблений и имён администрации (badnames.js); системные — админ «Советник»
    const bad = system ? (/^[a-zа-яё0-9_]{3,10}$/i.test(nick) ? null : 'Ник: 3–10 символов.') : require('./badnames').nickProblem(nick);
    if (bad) return { error: bad };
    if (password.length < 5 && !system) return { error: 'Пароль слишком короткий (минимум 5 символов).' };
    if (this.db.accts[acct]) return { error: 'Такой логин (email) уже зарегистрирован.' };
    if (Object.prototype.hasOwnProperty.call(this.db.users, nick)) return { error: 'Такой ник уже занят.' };
    if (!system && (['admin', 'советник'].includes(nick.toLowerCase()) || acct === 'admin')) return { error: 'Этот ник зарезервирован.' }; // «Admin», «ADMIN» — нельзя, чтобы не выдавать себя за админа
    if (!email && acct.includes('@')) email = acct;
    const id = this.db.nextId++;
    const raceId = C.RACES[Number(race)] || 'humans';
    this.db.accts[acct] = login;
    this.db.users[login] = { id, login: nick, acct, pass: hashPassword(password), email: String(email || '').slice(0, 60), race: raceId, created: Date.now(), castleId: null, reputation: 10, gold: 0 }; // стартовая репутация 10; золото — только донат
    this.byId.set(id, this.db.users[login]);
    // подарок новичку: Премиум на NEWBIE_PREMIUM_DAYS дней с регистрации (по умолчанию 3) — один раз, сам не продлевается;
    // premiumGift — до какого времени подарок (советник напоминает при входе). Советнику (админ) и ботам — нет
    const gift = system ? 0 : Number(process.env.NEWBIE_PREMIUM_DAYS ?? 3);
    if (gift > 0) { const nu = this.db.users[login]; nu.premium = nu.premiumGift = nu.created + gift * 86400000; }
    const castle = this.createCastle(this.db.users[login]);
    this.db.users[login].castleId = castle.id;
    this.db.users[login].castleIds = [castle.id]; // первый — столица
    const adm = gift > 0 && this.adminUser ? this.adminUser() : null; // приветственное письмо о подарке — от Советника, в «Сообщения»
    if (adm) {
      const days = `${gift} ${require('./words').plural(gift, 'день', 'дня', 'дней')}`;
      const until = new Date(this.db.users[login].premium).toLocaleString('ru-RU', { timeZone: 'Europe/Moscow', day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' });
      this.sendMail(adm, login, `Подарок новичку: Премиум на ${days}`, `Приветствую, правитель! Добро пожаловать в Средневековье!\n🎁 В подарок новичку — Премиум Завоеватель на ${days}, до ${until} (МСК).\n`
        + 'С ним: 5 построек одновременно, опыт генерала ×2, прирост населения +50%, отправка армий по расписанию, ритуалы и тренировка во всех замках из одного окна, цвет сообщений и звание Премиум в профиле.\n'
        + 'Стройте, собирайте армию и ищите союзников — удачи в битвах!');
    }
    this.store.save();
    return { user: this.db.users[login] };
  }

  // смена пароля игроком: нужен старый пароль; все прочие сессии завершаются
  changePassword(user, oldPass, newPass, ip = '', dev = '') {
    if (!checkPassword(String(oldPass || '').toLowerCase(), user.pass)) return { error: 'Старый пароль указан неверно.' };
    newPass = String(newPass || '').toLowerCase();
    if (newPass.length < 5) return { error: 'Новый пароль слишком короткий (минимум 5 символов).' };
    if (newPass.length > 40) return { error: 'Новый пароль слишком длинный.' };
    user.pass = hashPassword(newPass); user.tokens = []; passLogPush(user, 'self', ip, dev);
    this.store.save();
    return { ok: true };
  }
  // новый пароль по коду из Telegram (tgauth.js): старый не нужен, все входы завершаются
  setPasswordReset(user, newPass, ip = '', by = 'telegram') { user.pass = hashPassword(newPass); user.tokens = []; passLogPush(user, by, ip); this.store.save(); } // «Забыли пароль?»: по коду из Telegram или из письма (mail.js)
  // смена ника — только за золото (цена NICK_PRICE, по умолчанию 100); новый ник должен быть свободен, вход — по новому нику
  changeNick(user, nick) {
    nick = String(nick || '').trim();
    const price = Number(process.env.NICK_PRICE) || 100, oldKey = user.login, key = nick;
    if (user.admin) return { error: 'Ник администратора не меняется.' };
    const bad = require('./badnames').nickProblem(nick); if (bad) return { error: bad }; // английские буквы, без мата и «админских» ников
    if (nick === user.login) return { error: 'Это ваш текущий ник.' };
    if (Object.prototype.hasOwnProperty.call(this.db.users, key) || ['admin', 'советник'].includes(key.toLowerCase())) return { error: 'Такой ник уже занят.' };
    if ((user.gold || 0) < price) return { error: `Смена ника стоит ${require('./words').coinsAcc(price)}, у вас ${user.gold || 0}.` };
    this.goldChange(user, -price, `Смена ника: ${user.login} → ${nick}`);
    (user.nickLog = user.nickLog || []).push({ at: Date.now(), from: user.login, to: nick });
    delete this.db.users[oldKey]; this.db.users[key] = user; this.db.accts[user.acct] = key;
    user.login = nick; this.store.save();
    return { ok: true, price };
  }
  // название и описание активного замка
  castleInfo(user, name, desc) {
    const c = this.castleOf(user);
    name = String(name || '').replace(/[<>]/g, '').trim().slice(0, 24);
    if (name.length < 2) return { error: 'Название замка — от 2 символов.' };
    c.name = name; c.desc = String(desc || '').replace(/[<>]/g, '').trim().slice(0, 200);
    this.store.save();
    return { ok: true };
  }
  // вход по паролю. Если задан ADMIN_LOGIN (секретный логин админа), админ входит только под ним,
  // а в игре по-прежнему виден как admin; вход под «admin» тогда отклоняется как неверный.
  login(login, password) {
    let acct = String(login || '').trim().toLowerCase(); // вход — по логину (Email / Логин), не по нику
    const alias = String(process.env.ADMIN_LOGIN || '').trim().toLowerCase();
    if (alias && alias !== 'admin') {
      if (acct === alias) acct = (this.adminUser && this.adminUser() && this.adminUser().acct) || 'admin';
      else if (acct === 'admin') return null;
    }
    const key = this.db.accts[acct];
    if (!key || !Object.prototype.hasOwnProperty.call(this.db.users, key)) return null;
    const u = this.db.users[key];
    if (!u || !checkPassword(String(password || '').toLowerCase(), u.pass)) return null;
    return u;
  }

  passOk(u, password) { return !!u && checkPassword(String(password || '').toLowerCase(), u.pass); }
  userById(id) { return this.byId.get(id); }

  // ----- замки -----
  createCastle(user, at = null) {
    const id = this.db.nextId++;
    let x, y;
    if (at) ({ x, y } = at);
    else { // новые игроки — в первую от центра провинцию, где меньше PROV_CAP замков; внутри — свободная клетка не у самой границы
      const cnt = new Map(); for (const k of this.byXY.values()) { const p = provinceOf(k.x, k.y); cnt.set(p.n, (cnt.get(p.n) || 0) + 1); }
      const free = (X, Y) => { for (let dx = -SPAWN_GAP; dx <= SPAWN_GAP; dx++) for (let dy = -SPAWN_GAP; dy <= SPAWN_GAP; dy++) if (this.byXY.has((X + dx) * WORLD + (Y + dy))) return false;
        return !this.worldObjects(X, Y, 1, 1).some((o) => o.kind === 'object') && !this.objNear(X, Y); };
      let spot = null;
      for (const p of provOrder()) {
        if ((cnt.get(p.py * PROV_N + p.px + 1) || 0) >= PROV_CAP) continue;
        const x0 = p.px * PROV + PROV_EDGE, y0 = p.py * PROV + PROV_EDGE, w = Math.min(PROV - 2 * PROV_EDGE, WORLD - 1 - x0), h = Math.min(PROV - 2 * PROV_EDGE, WORLD - 1 - y0);
        if (w < 1 || h < 1) continue;
        // ровно: из случайных свободных клеток берётся та, что дальше всех от замков провинции (первый — ближе к середине)
        const mine = [...this.byXY.values()].filter((k) => provinceOf(k.x, k.y).n === p.py * PROV_N + p.px + 1), mx = x0 + (w - 1) / 2, my = y0 + (h - 1) / 2;
        let best = -Infinity;
        for (let k = 0; k < 300; k++) {
          const X = x0 + Math.floor(Math.random() * w), Y = y0 + Math.floor(Math.random() * h); if (!free(X, Y)) continue;
          const edge = 2 * (Math.min(X - p.px * PROV, (p.px + 1) * PROV - 1 - X, Y - p.py * PROV, (p.py + 1) * PROV - 1 - Y) + 0.5); // граница «отталкивает» как сосед
          const sc = mine.length ? Math.min(edge, ...mine.map((c) => Math.hypot(c.x - X, c.y - Y))) : -Math.hypot(X - mx, Y - my);
          if (sc > best) { best = sc; spot = { x: X, y: Y }; }
        }
        if (spot) break; // провинция тесная (старые замки) — следующая
      }
      if (!spot) for (let k = 0; !spot; k++) { const X = Math.floor(Math.random() * WORLD), Y = Math.floor(Math.random() * WORLD); if (!this.byXY.has(X * WORLD + Y)) spot = { x: X, y: Y }; }
      ({ x, y } = spot);
    }
    const castleGrid = new Int8Array(49).fill(-1);
    const landsGrid = new Int8Array(LANDS_N * LANDS_N).fill(-1);
    const castle = {
      id, owner: user.id, name: `Замок ${user.login}`, x, y,
      grid: { 0: castleGrid, 1: landsGrid },
      levels: { 0: new Int8Array(49), 1: new Int8Array(LANDS_N * LANDS_N) },
      res: { wood: 500, stone: 500, iron: 500, food: 500, people: 40 }, // старт: склад 2 ур. полон (вмещает 500)
      resAt: Date.now(),
      queue: [], layoutV: 2,
    };
    castleGrid[3 * 7 + 3] = 0; castle.levels[0][3 * 7 + 3] = 1; // Ратуша 1 ур. в центре
    castleGrid[2 * 7 + 1] = 1; castle.levels[0][2 * 7 + 1] = 2; // Склад 2 ур.
    // стартовые постройки на землях: по одной добывающей каждого вида
    for (const [bx, by, b] of [[1, 8, 7], [10, 0, 8], [12, 0, 9], [3, 5, 5], [6, 3, 6]]) {
      landsGrid[by * LANDS_N + bx] = b; castle.levels[1][by * LANDS_N + bx] = 1;
    }
    castle.landsV = 2; // земли — уже в новых уровнях (1–5)
    this.db.castles[id] = castle;
    this.byXY.set(x * WORLD + y, castle);
    return castle;
  }

  // активный замок игрока (все старые места работают через него); у игрока может быть несколько замков
  // золото (монеты) игрока: все изменения — через goldChange, с историей для окна «Казна»
  // noHall — перевод внутри альянса (казна): в Зал Славы не идёт, иначе «взнос — выдача» по кругу накручивал Богатство и Расточительство
  goldChange(user, delta, reason, noHall = false) {
    delta = Math.round(delta); if (!delta) return;
    const before = user.gold || 0; user.gold = before < 0 ? before + delta : Math.max(0, before + delta); // минус (возврат звёзд, tgpay.js) закрывается новыми монетами
    if (this.addStat && !noHall) this.addStat(user.id, delta > 0 ? 'goldIn' : 'goldOut', Math.abs(delta)); // Зал Славы: Богатство / Расточительство
    (user.goldLog = user.goldLog || []).push({ at: Date.now(), delta, reason, left: user.gold });
    if (user.goldLog.length > 200) user.goldLog.splice(0, user.goldLog.length - 200);
  }
  castleOf(user) { return this.db.castles[user.castleId]; }
  castlesOf(user) { if (!user.castleIds) user.castleIds = [user.castleId]; return user.castleIds.map((id) => this.db.castles[id]).filter(Boolean); }
  isCapital(castle) { const u = this.userById(castle.owner); return !!u && this.castlesOf(u)[0] === castle; }
  userRating(user) { return this.castlesOf(user).reduce((s, c) => s + this.rating(c), 0); }
  switchCastle(user, id) {
    if (!this.castlesOf(user).some((c) => c.id === Number(id))) return { error: 'Это не ваш замок.' };
    user.castleId = Number(id); this.store.save();
    return { ok: true };
  }

  // рейтинг замка: постройки замка + развитие Складов + земли; полный замок — 2200 (C.RATING)
  ratingParts(castle) {
    const sum = (a) => a.reduce((x, y) => x + y, 0);
    const R = C.RATING, extra = castle.storeExtraLv || 0; // уровни Складов, объединённых при переходе на 5 Складов
    let storeLv = extra;
    castle.grid[0].forEach((b, i) => { if (b === 1) storeLv += castle.levels[0][i]; });
    const p = {
      castle: Math.min(R.castleMax, Math.round((sum(castle.levels[0]) + (castle.wall || 0) + extra) * R.castle)),
      store: Math.min(R.storeMax, Math.round(storeLv * R.store)),
      lands: Math.min(R.landsMax, Math.round(castle.levels[1].reduce((x, y) => x + C.landEff(y), 0) * R.lands)),
      storeLv,
    };
    p.total = Math.min(R.max, p.castle + p.store + p.lands);
    return p;
  }

  rating(castle) { return this.ratingParts(castle).total; }

  buildingLevel(castle, buildingId) {
    if (buildingId === WALL_ID) return castle.wall || 0;
    let best = 0;
    for (const v of [0, 1]) castle.grid[v].forEach((b, i) => { if (b === buildingId) best = Math.max(best, castle.levels[v][i]); });
    return best;
  }

  // замок на картинке-фоне (раскладка v2): Ратуша — на площади (клетка 24), остальные здания — на 32 площадках (C.CASTLE_OK).
  // Складов — не больше 5: остаются самые высокие (и те, что сейчас строятся); вместимость и уровни остальных переходят в
  // castle.storeExtra / storeExtraLv (вместимость и рейтинг игрока не меняются), их стройки — отменяются, ресурсы — в Кладовую.
  castleLayoutFix(castle) {
    if (castle.layoutV === 2) return;
    const g = castle.grid[0], l = castle.levels[0], OK = new Set(C.CASTLE_OK), q0 = castle.queue || [];
    const items = [];
    for (let i = 0; i < 49; i++) if (g[i] >= 0) items.push({ b: g[i], lv: l[i], i, q: q0.filter((q) => q.view === VIEW.CASTLE && q.cell === i) });
    for (const q of q0) if (q.view === VIEW.CASTLE && !q.wall && q.cell >= 0 && g[q.cell] < 0 && !items.some((t) => t.i === q.cell)) items.push({ b: q.building, lv: 0, i: q.cell, q: q0.filter((x) => x.view === VIEW.CASTLE && x.cell === q.cell) });
    const stores = items.filter((t) => t.b === 1).sort((a, b) => (b.q.length - a.q.length) || b.lv - a.lv);
    const drop = stores.slice(C.STORE_MAX), dropSet = new Set(drop);
    const refund = { wood: 0, stone: 0, iron: 0, food: 0 };
    for (const t of drop) {
      castle.storeExtra = (castle.storeExtra || 0) + storeBonus(t.lv); castle.storeExtraLv = (castle.storeExtraLv || 0) + t.lv;
      for (const q of t.q) { for (const r of Object.keys(refund)) refund[r] += (q.cost && q.cost[r]) || 0; castle.queue = castle.queue.filter((x) => x !== q); }
    }
    const keep = items.filter((t) => !dropSet.has(t));
    const ng = new Int8Array(49).fill(-1), nl = new Int8Array(49), taken = new Set(), moved = [];
    const hall = keep.find((t) => t.b === 0);
    if (hall) { ng[24] = 0; nl[24] = hall.lv; taken.add(24); if (hall.i !== 24) moved.push([hall, 24]); }
    const rest = keep.filter((t) => t !== hall);
    for (const t of rest) if (OK.has(t.i) && t.i !== 24 && !taken.has(t.i)) { taken.add(t.i); t.to = t.i; }
    const free = C.CASTLE_OK.filter((i) => i !== 24 && !taken.has(i));
    for (const t of rest) if (t.to === undefined) { const k = free.shift(); if (k === undefined) { castle.storeExtra = (castle.storeExtra || 0) + (t.b === 1 ? storeBonus(t.lv) : 0); continue; } t.to = k; taken.add(k); }
    for (const t of rest) if (t.to !== undefined) { if (t.lv > 0) { ng[t.to] = t.b; nl[t.to] = t.lv; } if (t.to !== t.i) moved.push([t, t.to]); }
    for (const [t, to] of moved) for (const q of t.q) q.cell = to;
    castle.grid[0] = ng; castle.levels[0] = nl; castle.layoutV = 2;
    if (Object.values(refund).some((v) => v > 0)) { const u = this.userById(castle.owner); if (u && this.stashAdd) this.stashAdd(u, refund); }
    if (drop.length && this.event) this.event(castle.owner, `Замок «${castle.name}» перестроен: Складов теперь не больше ${C.STORE_MAX}, вместимость лишних Складов (${drop.length}) сохранена в оставшихся.`);
  }

  // убранные здания (C.GONE, с 22.10 — Таверна): клетка освобождается, всё потраченное на уровни и стройку — в Кладовую
  goneFix(castle) {
    const g = castle.grid[0], l = castle.levels[0], refund = { wood: 0, stone: 0, iron: 0, food: 0 }, names = new Set();
    const add = (c) => { for (const r of Object.keys(refund)) refund[r] += (c && c[r]) || 0; };
    for (let i = 0; i < g.length; i++) if (C.GONE[g[i]]) { const def = C.GONE[g[i]]; names.add(def.name); for (let lv = 1; lv <= l[i]; lv++) add(C.levelCost(def, lv)); g[i] = -1; l[i] = 0; }
    const q = (castle.queue || []).filter((x) => C.GONE[x.building]);
    if (q.length) { for (const x of q) { add(x.cost); names.add(C.GONE[x.building].name); } castle.queue = castle.queue.filter((x) => !q.includes(x)); }
    if (!names.size) return;
    const u = this.userById(castle.owner);
    if (u && this.stashAdd && Object.values(refund).some((v) => v > 0)) this.stashAdd(u, refund);
    if (this.event) this.event(castle.owner, `${[...names].join(', ')} больше нет в игре — ресурсы, потраченные на ${names.size > 1 ? 'эти здания' : 'это здание'} в замке «${castle.name}», вернулись в Кладовую.`);
  }

  capacity(castle) {
    let store = STORE.base + (castle.storeExtra || 0); // + вместимость Складов, объединённых при переходе на 5 Складов
    castle.grid[0].forEach((b, i) => { if (b === 1) store += storeBonus(castle.levels[0][i]); });
    let huts = 0;
    castle.grid[1].forEach((b, i) => { if (b === 6) huts += C.landEff(castle.levels[1][i]); }); // места — как у прежнего уровня
    const people = Math.round(STORE.people + STORE.peoplePerHut * C.HUT_CAP_MULT * huts);
    return { wood: store, stone: store, iron: store, food: store, people };
  }

  // добыча в час с учётом скорости мира
  rates(castle) {
    const r = { ...BASE_RATE };
    castle.grid[1].forEach((b, i) => {
      const def = C.BY_ID[b];
      if (def && def.produces) r[def.produces] += C.PROD[C.landEff(castle.levels[1][i])] * C.PROD_K[def.produces] * (C.LAND_YIELD[b] || 1);
    });
    r.people *= 1 + PEOPLE_SCI * ((this.sciOf ? this.sciOf(castle) : castle.sciences || {}).eco || 0); // наука «Экономика»: люди +0,37% за уровень (полные земли 1303 → 1400)
    if (this.isPremium(this.userById(castle.owner))) r.people *= 1.5; // премиум: население +50%
    const prod = this.bonus(castle).prod; // наука Экономика, религия Природа, артефакты
    for (const k of ['wood', 'stone', 'iron', 'food']) r[k] *= prod;
    for (const k of Object.keys(r)) r[k] = Math.round(r[k] * RES_SPEED + 1e-9);
    return r;
  }

  // довести ресурсы и очередь до момента now (ленивый расчёт)
  tick(castle, now = Date.now()) {
    if (castle.grid[1].length !== LANDS_N * LANDS_N) migrateLands(castle);
    fixPlaza(castle); fixWall(castle); this.castleLayoutFix(castle); this.goneFix(castle);
    const done = [];
    castle.queue.sort((a, b) => a.end - b.end);
    while (castle.queue.length && castle.queue[0].end <= now) {
      const item = castle.queue.shift();
      this.accrue(castle, item.end);
      if (item.wall) castle.wall = Math.max(castle.wall || 0, item.level); // стена — без клетки
      else { castle.grid[item.view][item.cell] = item.building; castle.levels[item.view][item.cell] = item.level; }
      done.push(item);
      if (this.addStat) this.addStat(castle.owner, 'built', 1); // задания: улучшено зданий
    }
    // снос: время вышло — здание убирается с клетки (если на ней всё ещё то же здание), лишние ресурсы сверх Склада пропадают
    if ((castle.razing || []).some((z) => z.end <= now)) {
      for (const z of castle.razing.filter((x) => x.end <= now).sort((a, b) => a.end - b.end)) {
        this.accrue(castle, z.end);
        if (castle.grid[z.view][z.cell] !== z.building) continue;
        castle.grid[z.view][z.cell] = -1; castle.levels[z.view][z.cell] = 0;
        const cap = this.capacity(castle); for (const r of C.RES) castle.res[r] = Math.min(castle.res[r], cap[r]);
        done.push({ ...z, raze: true }); this.cache = {};
      }
      castle.razing = castle.razing.filter((x) => x.end > now);
    }
    this.accrue(castle, now);
    this.tickTraining(castle, now); // тренировка войск, исследования, воскрешение генерала (army.js)
    if (done.length) this.store.save();
    return done;
  }

  accrue(castle, t) {
    const dtH = Math.max(0, t - castle.resAt) / 3600000;
    // ничейный замок (nobody.js) — ресурсы не растут (с 22.10): иначе без хозяина он был вечной кормушкой для грабежа
    if (this.isNobody && this.isNobody(castle.owner)) { castle.resAt = t; return; }
    const rate = this.rates(castle);
    const cap = this.capacity(castle);
    // сверх Склада (награда советника) ресурсы не растут, но и не срезаются — тратятся как обычно
    for (const r of C.RES) { const v = castle.res[r], n = v + rate[r] * dtH; castle.res[r] = Math.max(0, v > cap[r] ? Math.min(v, n) : Math.min(cap[r], n)); }
    castle.resAt = t;
  }

  // проверка и постановка в очередь: стройка нового здания или улучшение существующего
  startBuild(castle, view, cell, buildingId) {
    this.tick(castle);
    const size = GRID[view];
    if (!size || cell < 0 || cell >= size * size) return { error: 'Неверная клетка.' };
    const def = C.BY_ID[buildingId];
    if (!def) return { error: 'Неизвестное здание.' };
    if (buildingId === WALL_ID) return { error: 'Стена развивается в Ратуше.' };
    if (def.adminOnly && !(this.userById(castle.owner) || {}).admin) return { error: 'Это здание пока проверяет администрация — скоро откроется.' }; // Капкан (trap.js)
    if (castle.queue.some((q) => q.view === view && q.cell === cell)) return { error: 'Здесь уже идёт строительство.', state: 1 };
    if ((castle.razing || []).some((z) => z.view === view && z.cell === cell)) return { error: 'Здание сносится — сначала отмените снос.', state: 1 };
    const maxQ = this.isPremium(this.userById(castle.owner)) ? 5 : MAX_QUEUE; // премиум — 5 строек
    if (castle.queue.length >= maxQ) return { error: `Одновременно можно строить не больше ${maxQ} зданий.${maxQ < 5 ? ' С премиумом — 5.' : ''}` };
    const current = castle.grid[view][cell];
    let level;
    if (current === -1) {
      if ((view === VIEW.CASTLE) !== (def.layer === 'castle')) return { error: 'Это здание строится в другом месте.' };
      if (view === VIEW.LANDS) {
        const x = cell % LANDS_N, y = Math.floor(cell / LANDS_N);
        if (!landOptions(x, y).includes(buildingId)) return { error: 'На этой клетке такое здание не построить.' };
      }
      if (view === VIEW.CASTLE && C.CASTLE_PATH.includes(cell)) return { error: 'Здесь строить нельзя.' };
      if (buildingId === 1 && castle.grid[0].filter((b) => b === 1).length + castle.queue.filter((q) => q.view === VIEW.CASTLE && q.building === 1 && q.level === 1).length >= C.STORE_MAX) return { error: `Складов может быть не больше ${C.STORE_MAX}. Улучшайте построенные.` };
      if (def.unique && (this.buildingLevel(castle, buildingId) > 0 || castle.queue.some((q) => q.building === buildingId))) return { error: 'Такое здание уже есть в замке.' };
      level = 1;
    } else {
      if (current !== buildingId) return { error: 'Клетка занята другим зданием.', state: 1 };
      level = castle.levels[view][cell] + 1;
      if (level > (def.max || 20)) return { error: 'Достигнут максимальный уровень.' };
    }
    for (const [reqId, reqLvl] of Object.entries(def.req || {})) {
      if (this.buildingLevel(castle, Number(reqId)) < reqLvl) return { error: `Нужно: ${C.BY_ID[reqId].name} ${reqLvl} ур.` };
    }
    const cost = C.levelCost(def, level);
    const cap = this.capacity(castle);
    const busyPeople = castle.queue.reduce((s, q) => s + q.cost.people, 0);
    for (const r of C.RES) {
      if (castle.res[r] < cost[r]) return { error: 'Недостаточно ресурсов.', state: 2 };
    }
    if (busyPeople + cost.people > cap.people) return { error: 'Не хватает свободных людей.', state: 2 };
    for (const r of C.RES) if (r !== 'people') castle.res[r] -= cost[r];
    const time = Math.max(3, Math.round(buildTime(def, level, this.buildingLevel(castle, 0)) * this.bonus(castle).build)); // наука Инженерия
    const now = Date.now();
    const item = { view, cell, building: buildingId, level, start: now, end: now + time * 1000, cost };
    castle.queue.push(item);
    if (current === -1) castle.grid[view][cell] = -1; // клетка помечается клиентом как -2 (стройка)
    this.store.save();
    return { item };
  }

  // Стена: следующий уровень из окна Ратуши (без клетки; в очереди строек — как обычная стройка)
  startWall(castle) {
    this.tick(castle);
    const def = C.BY_ID[WALL_ID];
    if (castle.queue.some((q) => q.wall)) return { error: 'Стена уже строится.' };
    const maxQ = this.isPremium(this.userById(castle.owner)) ? 5 : MAX_QUEUE;
    if (castle.queue.length >= maxQ) return { error: `Одновременно можно строить не больше ${maxQ} зданий.${maxQ < 5 ? ' С премиумом — 5.' : ''}` };
    const level = (castle.wall || 0) + 1;
    if (level > (def.max || 20)) return { error: 'Стена построена до предела.' };
    for (const [reqId, reqLvl] of Object.entries(def.req || {})) if (this.buildingLevel(castle, Number(reqId)) < reqLvl) return { error: `Нужно: ${C.BY_ID[reqId].name} ${reqLvl} ур.` };
    const cost = C.levelCost(def, level), cap = this.capacity(castle), busy = castle.queue.reduce((s, q) => s + q.cost.people, 0);
    for (const r of C.RES) if (castle.res[r] < cost[r]) return { error: 'Недостаточно ресурсов.' };
    if (busy + cost.people > cap.people) return { error: 'Не хватает свободных людей.' };
    for (const r of C.RES) if (r !== 'people') castle.res[r] -= cost[r];
    const time = Math.max(3, Math.round(buildTime(def, level, this.buildingLevel(castle, 0)) * this.bonus(castle).build)), now = Date.now();
    const item = { view: VIEW.CASTLE, cell: -1, wall: true, building: WALL_ID, level, start: now, end: now + time * 1000, cost };
    castle.queue.push(item); this.store.save();
    return { item };
  }

  // «Снести»: через 30 минут здание убирается с клетки целиком (ресурсы не возвращаются); пока идёт снос, здание работает,
  // снос можно отменить (demolishCancel). Ратушу снести нельзя.
  demolish(castle, view, cell) {
    this.tick(castle);
    const size = GRID[view];
    if (!size || !(cell >= 0 && cell < size * size)) return { error: 'Неверная клетка.' };
    const b = castle.grid[view][cell];
    if (b < 0 || !castle.levels[view][cell]) return { error: 'Здесь нет здания.' };
    if (b === 0) return { error: 'Ратушу снести нельзя.' };
    if (castle.queue.some((q) => q.view === view && q.cell === cell)) return { error: 'Здание сейчас строится.' };
    castle.razing = castle.razing || [];
    if (castle.razing.some((z) => z.view === view && z.cell === cell)) return { error: 'Здание уже сносится.' };
    const now = Date.now(), z = { view, cell, building: b, level: castle.levels[view][cell], start: now, end: now + DEMOLISH_SEC * 1000 };
    castle.razing.push(z); this.store.save();
    return { ok: true, name: C.BY_ID[b].name, end: z.end, sec: DEMOLISH_SEC };
  }
  demolishCancel(castle, view, cell) {
    this.tick(castle);
    const z = (castle.razing || []).find((x) => x.view === view && x.cell === cell); if (!z) return { error: 'Снос не идёт.' };
    castle.razing = castle.razing.filter((x) => x !== z); this.store.save();
    return { ok: true, name: C.BY_ID[z.building].name };
  }

  // Объекты карты мира в прямоугольнике: замки игроков + руины и лагеря провинций (npcIn).
  // img — номер тайла клиента: 10 замок, 24 заброшенный замок (руины), 30–32 лагеря разбойников (лёгкий, средний, тяжёлый), 40–42 руны
  worldObjects(x0, y0, w, h) {
    const out = [];
    const castles = [];
    for (let y = y0; y < y0 + h; y++) for (let x = x0; x < x0 + w; x++) { const c = this.castleAt(x, y); if (c) castles.push(c); }
    for (const c of castles) {
      const owner = this.userById(c.owner);
      const al = this.allianceOf(owner);
      out.push({ kind: 'castle', x: c.x, y: c.y, img: 10, prem: this.isPremium(owner) || undefined, castleId: c.id, name: c.name, ownerId: owner.id, owner: owner.login, race: owner.nobody ? this.raceOf(c) : owner.race, nobody: owner.nobody ? 1 : undefined, rating: this.rating(c), alliance: al ? al.tag : null, allyId: al ? al.id : null, newbie: this.isNewbie(owner) || undefined, shield: this.castleShield(c) ? 1 : undefined, site: c.site ? { start: c.site.start, end: c.site.end } : undefined }); // site — недострой (Освоение, army.js)
    }
    for (const d of this.npcIn(x0, y0, w, h)) {
      const o = { kind: 'object', x: d.x, y: d.y, img: d.img, name: d.name };
      if (d.img === 24) { const st = (this.db.npc || {})[`${d.x}:${d.y}`]; o.loyalty = Math.round(st && st.loyalty !== undefined ? st.loyalty : 100); } // руины: захват бунтарями
      const rn = require('./runes').RUNES[d.img]; if (rn) o.rune = rn.key; // рунный камень: собирает отряд (поход «Сбор руны»)
      out.push(o);
    }
    return out;
  }

  // ----- почта -----
  sendMail(fromUser, toLogin, subject, text) {
    const to = this.db.users[String(toLogin || '').trim()];
    if (!to) return { error: 'Получатель не найден.' };
    this.db.messages = this.db.messages || [];
    const m = { id: this.db.nextId++, from: fromUser.id, to: to.id, subject: String(subject || '').slice(0, 80), text: String(text || '').slice(0, 4000), at: Date.now(), read: false, color: this.msgColor ? this.msgColor(fromUser) : '' };
    this.db.messages.push(m);
    if (this.tgNotify && fromUser && fromUser.id !== to.id) this.tgNotify(to.id, 'mail', `✉ Письмо от ${fromUser.login}: «${m.subject || 'без темы'}». Прочитать — в игре.`);
    this.store.save();
    return { message: m, to };
  }

  mailList(userId, folder) {
    const all = this.db.messages || [];
    return all.filter((m) => (folder === 1 ? m.from === userId : m.to === userId) && this.msgSees(m, userId)).slice(-30).reverse();
  }
  // видит ли игрок письмо: участник переписки и не удалил его у себя (удаление — только у себя, у собеседника письмо остаётся,
  // чтобы нельзя было спрятать оскорбления от модераторов; удалённое обоими — стирается совсем)
  msgSees(m, uid) { return (m.from === uid && !m.delFrom) || (m.to === uid && !m.delTo); }
  // «Изменить» → «Удалить отмеченное» (ids) или «Удалить разговор» (withId — собеседник): только у себя
  msgDelete(user, ids, withId) {
    const me = user.id, set = new Set([].concat(ids || []).map(Number)), other = withId !== undefined && withId !== null ? Number(withId) : null;
    let n = 0;
    for (const m of this.db.messages || []) {
      if (!this.msgSees(m, me)) continue;
      if (other !== null ? (m.from === me ? m.to : m.from) !== other : !set.has(m.id)) continue;
      if (m.from === me) m.delFrom = true;
      if (m.to === me) { m.delTo = true; m.read = true; } // удалённое непрочитанным не висит
      n++;
    }
    if (n) { this.db.messages = this.db.messages.filter((m) => !(m.delFrom && m.delTo)); this.store.save(); }
    return { ok: true, n };
  }
  // конверт в списке «Сообщения»: удалить все переписки ('all'), прочитанные ('read') или с новыми сообщениями ('new') —
  // только у себя, как «Удалить разговор»; 'readall' — отметить все сообщения прочитанными. dialogs — сколько переписок затронуто
  msgBulk(user, op) {
    const me = user.id, mine = (this.db.messages || []).filter((m) => this.msgSees(m, me)), who = (m) => (m.from === me ? m.to : m.from);
    if (op === 'readall') { let n = 0; for (const m of mine) if (m.to === me && !m.read) { m.read = true; n++; } if (n) this.store.save(); return { n }; }
    const fresh = new Set(mine.filter((m) => m.to === me && !m.read).map(who));
    const pick = mine.filter((m) => op === 'all' || (op === 'new' ? fresh.has(who(m)) : !fresh.has(who(m))));
    return { ...this.msgDelete(user, pick.map((m) => m.id)), dialogs: new Set(pick.map(who)).size };
  }
  // «Переслать» сообщение другому игроку — с пометкой, от кого оно; фото — той же картинкой (пока не истекла), отчёт — снова отчётом
  msgForward(user, id, toLogin) {
    const m = (this.db.messages || []).find((x) => x.id === Number(id) && this.msgSees(x, user.id));
    if (!m) return { error: 'Сообщение не найдено.' };
    if (m.rep) return this.reportForward(user, m.rep, toLogin);
    const k = String(toLogin || '').trim(), byKey = Object.prototype.hasOwnProperty.call(this.db.users, k) ? this.db.users[k] : null;
    const to = byKey || (k ? Object.values(this.db.users).find((x) => x.login.toLowerCase() === k.toLowerCase()) : null);
    if (!to || to.bot) return { error: 'Игрок не найден.' };
    if (to.id === user.id) return { error: 'Себе переслать нельзя.' };
    const deny = this.canReach ? this.canReach(user, to, 'msg') : null; if (deny) return { error: deny }; // чёрный список — как для писем
    const pic = m.pic && this.picGet && this.picGet(m.pic) ? m.pic : null;
    if ((m.pic || m.picGone) && !pic) return { error: 'Фото уже удалено (фото хранятся 3 часа) — переслать нельзя.' };
    const lim = this.tooOften ? this.tooOften(user, 'mail') : null; if (lim) return { error: lim }; // не чаще раза в секунду, как письма
    const r = this.sendMail(user, to.login, 'Переслано', pic ? '[фото]' : m.text);
    if (r.error) return r;
    r.message.fwd = (this.userById(m.from) || { login: '?' }).login;
    if (pic) { r.message.pic = pic; r.message.picExp = m.picExp; }
    this.store.save();
    return { ok: true, msg: `Сообщение переслано игроку ${to.login}.`, to };
  }
  // «История» переписки с игроком: по 20 сообщений на страницу, по умолчанию — последняя (новые)
  dialogHistory(user, otherId, page, per = 20) {
    const o = this.userById(Number(otherId)); if (!o) return { error: 'Игрок не найден.' };
    const all = (this.db.messages || []).filter((x) => ((x.from === user.id && x.to === o.id) || (x.from === o.id && x.to === user.id)) && this.msgSees(x, user.id));
    const pages = Math.max(1, Math.ceil(all.length / per));
    let p = Math.floor(Number(page)); if (!Number.isFinite(p) || p < 0 || p >= pages) p = pages - 1;
    return { with: { id: o.id, login: o.login, race: o.race, avatar: o.avatar || 0 }, page: p, pages, total: all.length, list: all.slice(p * per, p * per + per) };
  }
}

// армии, функции зданий, админ (server/src/army.js)
require('./army').install(Game, { buildTime, landOptions });
// кабинет: профиль, репутация, друзья, чат, Зал Славы (server/src/social.js)
require('./social').install(Game);
// администратор: 20 замков и все админ-команды (server/src/admin.js)
require('./admin').install(Game);
require('./avatar').install(Game);
require('./royal').install(Game);
require('./ally').install(Game);
require('./premium').install(Game);
require('./security').install(Game);
require('./forum').install(Game);
require('./chatpoll').install(Game); // опрос в общем чате (только админ)
require('./wheel').install(Game); // Колесо Фортуны в общем чате (запускает админ)
require('./chatmod').install(Game); // предупреждения в чате и закрытие чата на время (модераторы)
require('./news').install(Game);
require('./smod').install(Game);
require('./stash').install(Game);
require('./metrics').install(Game);
require('./anomaly').install(Game);
require('./secwatch').install(Game);
require('./tgbackup').install(Game);
require('./shop').install(Game);
require('./tgauth').install(Game);
require('./mail').install(Game); // привязка почты и «Забыли пароль?» по коду на почту
require('./tgpay').install(Game);
require('./shield').install(Game);
require('./friends').install(Game);
require('./pics').install(Game);
require('./zags').install(Game);
require('./dungeon').install(Game); // Подземелье: лагеря археологов, раскопки и кража артефактов
require('./chests').install(Game);
require('./coin').install(Game);
require('./market').install(Game);
require('./privacy').install(Game);
require('./battlerank').install(Game);
require('./quests').install(Game);
require('./hero').install(Game);
require('./runes').install(Game);
require('./boss').install(Game);
require('./closedtest').install(Game);
require('./staff').install(Game); // «МАСТЕРА»: общение админа и тестеров // после admin.js: дополняет adminOp командами test…
require('./hunt').install(Game);
require('./trap').install(Game); // «Алтарь» → Зона охоты: Генералы бьют чудовищ стихий (hunt.js)
require('./link').install(Game); // «СВЯЗЬ»: переписка игроков с мастерами игры (после staff.js)
require('./honors').install(Game); // медали в профиле («Первопроходец»): дополняет adminOp командами honor…
require('./nobody').install(Game); // «Забросить замки» (админ): замки — ничьи, захват без столицы; обёртки над army.js, royal.js, friends.js — последним

module.exports = { PROV, PROV_CAP, PROV_N, PROV_EDGE, PROV_NPC, CAMP_IMGS, NPC_BACK_SEC, provinceOf, provNo, onProvEdge, passLogPush, checkPassword, meadowAt, fixPlaza, migrateLands, LANDS_N, WORLD, Game, Store, STORE, BASE_RATE, PEOPLE_FACTOR, storeBonus, RES_SPEED, buildTime, VIEW, GRID, landOptions, SPEED, MAX_QUEUE, LANDS_BASE, LANDS_DECOR, LANDS_EDGE };
