#!/data/data/com.termux/files/usr/bin/sh
# Запуск игры «Война Королей»: потом открыть в Chrome http://localhost:8080 (admin / admin)
cd "$(dirname "$0")/server" && exec node src/index.js
