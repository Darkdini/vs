#!/data/data/com.termux/files/usr/bin/sh
# Запуск игры «Война Королей»: потом открыть в Chrome http://localhost:8080
# Пароль admin на новом сервере — случайный: смотрите в консоли или в server/data/ADMIN_PASSWORD.txt
cd "$(dirname "$0")/server" && exec node src/index.js
