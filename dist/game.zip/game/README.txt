Война Королей — браузерная игра

Запуск (Termux):  sh ~/game/start.sh
Открыть в Chrome: http://localhost:8080
Админ: логин admin, пароль admin
Остановить: Ctrl+C
